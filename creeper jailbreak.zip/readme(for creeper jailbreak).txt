please run the objective c file("creeper jailbreak for ios 11-11.4.1.m") in the same file path with the other files downloaded in https://github.com/GeoSn0w/Blizzard-Jailbreak/

warning : there is no jailbroken store,only for developers!

NO WARRANCE  WILL BE COVERED,USE AT YOUR OWN RISK!


credits: GeoSn0w

Pwned4ever2️⃣

twitter: @pwned4ever2


ready t0 get t0 the gr00t???
tfp0 exploit ready/ready to escape the sandb0x/ready to jailbreak

lets go to gr00t!







